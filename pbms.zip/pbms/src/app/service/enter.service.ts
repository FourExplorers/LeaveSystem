import { Injectable,Inject } from '@angular/core';
import { Http, Headers,Response} from '@angular/http';


@Injectable()
export class EnterService {
  
  constructor() { 
    
  }
}
