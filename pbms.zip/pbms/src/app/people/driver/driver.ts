export class Driver {

    id: number;
    driverId: string;
    fromtime: string;
    totime: string;
    workline: string;
}
