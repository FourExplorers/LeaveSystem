export class line{


    id: number;
    lineId: string;
    stations: string;


}