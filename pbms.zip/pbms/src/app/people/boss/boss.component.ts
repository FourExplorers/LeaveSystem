import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-boss',
  templateUrl: './boss.component.html',
  styleUrls: ['./boss.component.css']
})
export class BossComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
