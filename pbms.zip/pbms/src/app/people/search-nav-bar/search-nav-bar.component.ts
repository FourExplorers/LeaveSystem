import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-nav-bar',
  templateUrl: './search-nav-bar.component.html',
  styleUrls: ['./search-nav-bar.component.css']
})
export class SearchNavBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
